struct Pokemon
{
    char name[50];
    int hp;
    int lv;
};
 
void InputData(struct Pokemon *);
void ShowInfo(struct Pokemon);

