#include <stdio.h>
#include "pokemon.h"


void InputData(struct Pokemon *p){
	scanf("%s", &p->name);
    scanf("%d", &p->hp);
    scanf("%d", &p->lv);
}


void ShowInfo(struct Pokemon p){
    printf("Name: %s\n", p.name);
    printf("Lv: %d\n", p.hp);
    printf("HP: %d\n\n", p.lv);
}

