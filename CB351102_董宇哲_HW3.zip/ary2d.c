#include <stdio.h>
#define SUBJECTNUM 3
#define STUDENTNUM 5

int main(int argc, char *argv[]) {
	int i, j, heighestindex, sum=0, totalsum=0;
	int score[STUDENTNUM][SUBJECTNUM] = {0};
	double avg, totalavg;
	double avgarray[STUDENTNUM] = {0};
	double highestavg = -100;
	
	// input scores
	for (i=0; i<STUDENTNUM; i++) {
		scanf("%d%d%d", &score[i][0], &score[i][1], &score[i][2]);
	}
	
	for (i=0; i<STUDENTNUM; i++) {
		printf("student %d\n", i+1);
		for (j=0; j<SUBJECTNUM; j++) {
			sum += score[i][j];
			totalsum += score[i][j];
			printf(" %d: %d\n", j+1, score[i][j]);
		}
		avg = (sum*1000 / SUBJECTNUM);
		avgarray[i] = avg / 1000;
		printf(" sum: %d\n", sum);
		printf(" avg: %.2f\n", avg/1000);
		sum = 0;
	}
	totalavg = (totalsum*1000)/(SUBJECTNUM*STUDENTNUM);
	printf("total: %d, avg: %.2f\n", totalsum, totalavg/1000);
	
	// calculate the highest avg score
	for (i=0; i<STUDENTNUM; i++) {
		if (avgarray[i]>highestavg) {
			highestavg = avgarray[i];
			heighestindex = i+1; 
		}
	}
	
	printf("highest avg: student %d: %.2f", heighestindex, highestavg);
	
	return 0; 
}
