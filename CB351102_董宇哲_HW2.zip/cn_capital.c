#include <stdio.h>

 
int main(int argc, char *argv[]) {
    int i, N, temp, tempOutput, num;
    int array[] = {10000, 1000, 100, 10, 1};
 
    scanf("%d", &num);
 
    tempOutput = num;
    if (num!=0 && num<99999) {
        for (i=0; i<5; i++) {
            temp = (int)(tempOutput/array[i]);
            tempOutput = (int)(tempOutput-(temp*array[i]));
 
            if (temp!=0) {
                switch (temp) {
                    case 1:
                        printf("壹");
                        break;
                    case 2:
                        printf("貳");
                        break;
                    case 3:
                        printf("參");
                        break;
                    case 4:
                        printf("肆");
                        break;
                    case 5:
                        printf("伍");
                        break;
                    case 6:
                        printf("陸");
                        break;
                    case 7:
                        printf("柒");
                        break;
                    case 8:
                        printf("仈");
                        break;
                    case 9:
                        printf("玖");
                        break;
                }
                switch (i) {
                    case 0:
                        printf("萬");
                        break;
                    case 1:
                        printf("仟");
                        break;
                    case 2:
                        printf("佰");
                        break;
                    case 3:
                        printf("拾");
                        break;
                }
            }
        }
        printf("元整");
    } else {
        printf("out of range");
    }
 
    return 0;
}