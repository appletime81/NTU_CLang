#include <stdio.h>
#include <stdlib.h>

#define SIZE 5

int main(int argc, char *argv[]) {
    int i, j, A = 0, B = 0, ctrlLoop = 1;
    char ans[SIZE];
    char inputChar[SIZE];

    // input ans and guessNum
    scanf("%s", &ans);

    while (ctrlLoop) {
        scanf("%s", &inputChar);
        for (i = 0; i < SIZE; i++) {
            for (j = 0; j < SIZE; j++) {
                if (ans[i] == '\0' || inputChar[i] == '\0') {}
                else if (i == j && ans[i] == inputChar[j]) {
                    A += 1;
                } else if (i != j && ans[i] == inputChar[j]) {
                    B += 1;
                }
            }
        }
        if (A == 4) {
            ctrlLoop = 0;
        }
        printf("%dA%dB\n", A, B);
        A = 0;
        B = 0;
    }
    printf("You Win!\n");
    system("PAUSE");
    return 0;
}
